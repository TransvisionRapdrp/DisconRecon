package com.example.disconrecon_test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.disconrecon_library.WrapperApplication;

public class MainActivity extends WrapperApplication {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
