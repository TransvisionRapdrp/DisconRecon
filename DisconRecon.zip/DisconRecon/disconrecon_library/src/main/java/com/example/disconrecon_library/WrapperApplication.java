package com.example.disconrecon_library;

import android.app.Application;

public class WrapperApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
