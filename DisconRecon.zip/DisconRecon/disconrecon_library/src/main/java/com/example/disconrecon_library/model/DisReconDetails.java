package com.example.disconrecon_library.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class DisReconDetails implements Serializable {
    public String getACCT_ID() {
        return ACCT_ID;
    }

    public String getARREARS() {
        return ARREARS;
    }

    public String getRE_DATE() {
        return RE_DATE;
    }

    public String getDIS_DATE() {
        return DIS_DATE;
    }

    public String getPREVREAD() {
        return PREVREAD;
    }

    public String getCONSUMER_NAME() {
        return CONSUMER_NAME;
    }

    public String getADD1() {
        return ADD1;
    }

    public String getLAT() {
        return LAT;
    }

    public String getLON() {
        return LON;
    }

    public String getMTR_READ() {
        return MTR_READ;
    }

    public String getCOMMENTS() {
        return COMMENTS;
    }

    public String getREMARKS() {
        return REMARKS;
    }

    @SerializedName("ACCT_ID")
    @Expose
    private String ACCT_ID;
    @SerializedName("ARREARS")
    @Expose
    private String ARREARS;
    @SerializedName("RE_DATE")
    @Expose
    private String RE_DATE;
    @SerializedName("DIS_DATE")
    @Expose
    private String DIS_DATE;
    @SerializedName("PREVREAD")
    @Expose
    private String PREVREAD;
    @SerializedName("CONSUMER_NAME")
    @Expose
    private String CONSUMER_NAME;
    @SerializedName("ADD1")
    @Expose
    private String ADD1;
    @SerializedName("LAT")
    @Expose
    private String LAT;
    @SerializedName("LON")
    @Expose
    private String LON;
    @SerializedName("MTR_READ")
    @Expose
    private String MTR_READ;
    @SerializedName("COMMENTS")
    @Expose
    private String COMMENTS;
    @SerializedName("REMARKS")
    @Expose
    private String REMARKS;

    public String getUSER_ROLE() {
        return USER_ROLE;
    }

    public void setUSER_ROLE(String USER_ROLE) {
        this.USER_ROLE = USER_ROLE;
    }

    private String USER_ROLE;
}
