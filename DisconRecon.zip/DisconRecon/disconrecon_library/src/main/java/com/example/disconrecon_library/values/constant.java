package com.example.disconrecon_library.values;

public class constant {
    public static String FTP_HOST = "ftp2.hescomtrm.com";
    public static String FTP_USER = "TRMFTP01";
    public static String FTP_PASS = "TrmFTp1$";
    public static int FTP_PORT = 21;

    public static final String TEST_URL1 = "http://test_bc_service.hescomtrm.com/TicketingService.asmx/";
    public static final String PROD_URL1 = "http://bc_service.hescomtrm.com/TicketingService.asmx/";

    public static final String TEST_URL2 = "http://test_bc_service.hescomtrm.com/TRMCareService.asmx/";
    public static final String PROD_URL2 = "http://bc_service.hescomtrm.com/TRMCareService.asmx/";

    public static final String TEST_URL3 = "http://test_bc_service.hescomtrm.com/Service.asmx/";
    public static final String PROD_URL3 = "http://bc_service.hescomtrm.com/Service.asmx/";

    /*------------------------------Application Packages------------------------------*/
    public static final String PROD_APP = "com.example.disconrecon";
    public static final String TEST_APP = "com.example.disconrecon_test";

    public static final int DOWNLOAD_FILE_ERROR = 9;
    public static final int DOWNLOAD_FILE_SUCCESS = 10;
    public static final int DOWNLOAD_FILE_FAILURE = 11;
    public static final int LOGIN_SUCCESS = 12;
    public static final int LOGIN_FAILURE = 13;
    public static final int APK_FILE_DOWNLOADED = 18;
    public static final int APK_FILE_NOT_FOUND = 19;
    public static final int REQUEST_RESULT_SUCCESS = 23;
    public static final int REQUEST_RESULT_FAILURE = 24;
    public static final int INSERT_SUCCESS = 25;
    public static final int INSERT_FAILURE = 26;
    public static final int SUBDIV_RESULT_SUCCESS = 27;
    public static final int SUBDIV_RESULT_FAILURE = 28;
    public static final String PREFS_TICKET_ID = "Ticket_Id";
    public static final String PREFS_IMAGE_NAME = "ImageName";
    public static final String PREFS_LOGIN_ROLE = "Role";
    public static String MY_API_KEY = "AIzaSyBkzzbp44Bsw2kClSadmkDWAB2VLG6--m0";

}
