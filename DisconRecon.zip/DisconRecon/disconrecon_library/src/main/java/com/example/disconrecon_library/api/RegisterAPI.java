package com.example.disconrecon_library.api;

import com.example.disconrecon_library.model.DisReconDetails;
import com.example.disconrecon_library.model.LoginDetails;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface RegisterAPI {
    @POST("mr_login")//1
    @FormUrlEncoded
    Call<List<LoginDetails>> getLoginDetails2(@Field("MRCode") String MRCode, @Field("DeviceId") String DeviceId, @Field("PASSWORD") String PASSWORD);

    @POST("DisConList")//2
    @FormUrlEncoded
    Call<List<DisReconDetails>> getDisconList(@Field("MRCode") String MRCode, @Field("Date") String Date);

    @POST("ReConList")//3
    @FormUrlEncoded
    Call<List<DisReconDetails>> getReconList(@Field("MRCode") String MRCode, @Field("Date") String Date);
}