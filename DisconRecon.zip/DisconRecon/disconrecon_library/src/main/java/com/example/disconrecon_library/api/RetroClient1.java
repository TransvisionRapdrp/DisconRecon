package com.example.disconrecon_library.api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.example.disconrecon_library.SplashActivity.PACKAGE_NAME;
import static com.example.disconrecon_library.values.constant.PROD_APP;
import static com.example.disconrecon_library.values.constant.PROD_URL1;
import static com.example.disconrecon_library.values.constant.TEST_APP;
import static com.example.disconrecon_library.values.constant.TEST_URL1;


public class RetroClient1 {
    private static String BASE_URL = PROD_URL1;

    public RetroClient1() {
        if (PACKAGE_NAME.equals(PROD_APP)) {
            BASE_URL = PROD_URL1;
        } else if (PACKAGE_NAME.equals(TEST_APP)) {
            BASE_URL = TEST_URL1;
        }
    }

    private static Retrofit getRetrofitInstance() {
        return new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    public RegisterAPI getApiService() {
        return getRetrofitInstance().create(RegisterAPI.class);
    }
}
